<!DOCTYPE html>
<html>
  <head>
    <title>Am System</title>
    <!--Bootstrap Linking-->
    <link
      rel="stylesheet"
      href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"
    />
    <link rel="stylesheet" href="css/s-list.css">
    <style>
      .myform{
            margin-top: 3%;
            background-color: #0275d8;
            width: 30%;
            display: block;
            margin-left: auto;
            margin-right: auto;
            padding: 6%;
            border-radius: 20px;
        }
        .label-input{
          font-style: italic;
        }
        .list{
            color: white;
            margin-left: 5%;
        }
        .text{
          color: white;
        }
        .nav-ul li a {
         color: silver;
      }
      .nav-ul li a:hover {
        color: white;
        background-color: #0000;
      }
      .show{
       margin-top: -5%;
       margin-left: -50%;
      }
      h1{
        margin-top: 5%;
      }
    </style>
</head>
<body>
<nav class="navbar">
      <div class="container">
        <div class="navbar-header">
          <button
            type="button"
            class="navbar-toggle collapsed"
            data-toggle="collapse"
            data-target="#navbar"
            aria-expanded="false"
            aria-controls="navbar"
          >
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right nav-ul">
            <li><a href="teacher.php">Dashboard</a></li>
            <li>
              <a href="cre-student.html">Create Student</a>
            </li>
            <li><a href="student-ia.php">Marks Entry</a></li>
            <li><a href="statistics.php">Statistics</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="logout.php">Logout</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <p class="text-center text-primary show"><span class="showcase">A</span>M System</p>
    <h1 class="text-center">Text Books & Notes</h1>
    <div class="myform">
        <form method="POST" action="upload.php" enctype="multipart/form-data">
            <label class="label-input">Choose a file for upload<sup class="text-danger"> *</sup></label>
            <input type="file" name="file" class="form-control-file"><br>
            <input type="submit" value="Upload" class="btn"><br><br>
            <?php
$files = scandir("uploads");
for ($a = 2; $a < count($files); $a++)
{
    ?>
    <p>
        <?php echo $files[$a]; ?>
        <a class="list" href="uploads/<?php '<p class="text">echo $files[$a];</p>' ?>" download="<?php echo $files[$a]; ?>">
            Download
        </a>
    </p>
    <?php
}
?>
        </form>
    </div>
</body>
</html>

