<!DOCTYPE html>
<html>
    <head>
        <title>Am System</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/s-list.css">
        <style>
        .a-list {
             margin-top: 3%;
            margin-left: 7%;
        }
        h1{
            margin-top: 5%;
        }
        .nav-ul li a {
        color: silver;
      }
      .nav-ul li a:hover {
        color: white;
        background-color: #0000;
      }
      .showcase {
        margin-left: 1%;
        font-size: 2.7rem;
      }
      p {
        margin-left: -30%;
        margin-top: -5%;
      }
      .active {
        opacity: 0.5;
      }
      .active:hover {
        opacity: 1;
      }
        </style>
    </head>
<body>
<nav class="navbar">
      <div class="container">
        <div class="navbar-header">
          <button
            type="button"
            class="navbar-toggle collapsed"
            data-toggle="collapse"
            data-target="#navbar"
            aria-expanded="false"
            aria-controls="navbar"
          >
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>

        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right nav-ul">
            <li><a href="teacher.php">Dashboard</a></li>
            <li class="active">
              <a href="cre-student.html">Create Student</a>
            </li>
            <li><a href="student-ia.php">Marks Entry</a></li>
            <li><a href="notes.php">Upload</a></li>
            <li><a href="statistics.php">Statistics</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="logout.php">Logout</a></li>
          </ul>
        </div>
    
      </div>
    </nav>
    <p class="text-center text-primary"><span class="showcase">A</span>M System</p>
    <h1 class="text-center">Student Assessment Mark List</h1>
    <table class="a-list">
     <thead class="bg-dark">
        <tr>
            <th scope="col" >Name</th>
            <th scope="col">Batch No</th>
            <th scope="col">Subject 1</th>
            <th scope="col">Subject 2</th>
            <th scope="col">Subject 3</th>
            <th scope="col">Subject 4</th>
            <th scope="col">Subject 5</th>
            <th scope="col">Subject 6</th>
        </tr>
     </thead>
      
     <?php $conn = mysqli_connect("localhost", "root", "", "entry");
        // Check connection
        if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        }
        $sql = "SELECT username, password, gender, email, branch, course, phoneCode, phone FROM marks";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
        echo "<tr class='body-row'><td>"  . $row["username"] . "</td><td>"
        . $row["password"]. "</td><td>" . $row["gender"] . "</td><td>" . $row["email"] 
        . "</td><td>" . $row["branch"] . "</td><td>" . $row["course"]
        . "</td><td>". $row["phoneCode"]. "</td><td>". $row["phone"] . "</td></tr>" ;
        }
        echo "</table>";
        } else { echo "0 results"; }
        $conn->close();
     ?>
   </table>
</body>
</html>