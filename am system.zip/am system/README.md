# Attendance Management System 
-- Am system is a attendance management system in schools, colleges and institutes.


# Project Description
-- This attendance management system is more useful for schools, colleges, and institues it's add on more features on the website.

-- This system will also help in evaluating attendane eligibility criteria of a student.

-- It use both faculty and students

  # Faculty Uses:
        -- It facilitates to access the attendance information of a particular student in a particular class.
        -- To create, read, update and delete a classes & students details
        -- And check the overall performance of students
        -- Faculty to enter the asssement marks 
        -- And also access the basic tools of the website like calculator, to do list, counter system, timer system
                
  # Students Uses:
        -- Students use the website for checking assessment marks, particular student details and downloading the textbooks and notes.
        -- And also access the basic tools of the website like calculator, to do list, counter system, timer system


# Language used
-- Frontend

          -- HTML

          -- CSS

          -- Javascript

          -- Bootstrap 5
      
-- Backend

          -- PHP

          -- SQL

-- Others

          -- Firebase
 
 
# Softwares Used

              -- Visual code stdio
              
              -- Xampp sever (Apache server & phpmyadmin)
              
              -- mySQL workbench


# Work Procedure

-- First of all both students and faculty to need login in the website

-- After successfully login next is a dashboard page,click the menu icon view the sidebar of the website

-- Sidebar contains lot of options like faculty login, student list, assessment details, notes and also have an additional tools like To do list, timer system, counter system,
basic calculator.

-- Faculty login is a sub system of the project, if you need to enter the faculty dashboard must be login, there is no sign in option, if you are need to sign in
find the request form of the page using these contact the admin.
           
-- After login to access the dashboard if you create student or add the another class or to enter the assessment marks of the students that option are there and also   take the attendance of the class, check the statistics of a particular students or overall class performance.
        
-- Also Faculty upload any kind of notes all format is applicable on the site like pdf, images, zip, documents etc...
 
 -- Finally students viewing the faculty response from the home dashboard like assessment marks, student details, notes downloading.
 
 # Database
-- It also included zip folder

      -- Folder name "sql"
      
      -- File name "attendance"

# Case Diagram

-- And also check the case diagram pdf for understanding, it attached in the zip folder

# Website Demo

-- Website images also included in folder

   --Folder name "Website Images
 
   
# Conclusion of the project

-- Today student attendance management systems becoming a mandatory part of the digital revolution , taking over schools all over the world.

-- They are becoming increasingly popular in educational institutes because of the many benefits to the school, colleges and institutes

# This project is developed by
                           -- Pranav Kumar S 
                           -- Shiva Shankar A
                           -- Suriya Prakaash D
                           -- Vasundra R
                           -- Kabileshwaran R
                           -- Sathish Kumar M
                              From Department of Instrumentation And Control Engineering at Saranathan College Of Engineering 
                              
                              # Thank You!❤              
         
        
   


     
