<html>
 <head>
  <link rel="stylesheet" href="css/style.css"/>
  <title>Am System</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/bootstrap-theme.min.css">
  <link rel="stylesheet" href="css/c3.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/highcharts.js"></script>
  <script src="js/highcharts-exporting.js"></script>
  <script src="js/jquery.knob.js"></script>
  <!--<script src="js/student.js"></script>-->
  <link href="navbar-fixed-top.css" rel="stylesheet">
  <style>
    body{
      background-color: #212529;
    }
.showcase {
  color: #f1a900;
  font-size: 2.7rem;
  font-style: italic;
  font-weight: bold;
}

.nav-ul li a {
  color: silver;
}
.nav-ul li a:hover {
  color: white;
  background-color: #0000;
}
.text-white {
  color: white;
}
label{
  color: white;
}
#getAttendance{
  margin-top: 5%;
}
#chart{
  margin:3%;
}
  </style>
 </head>
 <body>
   <!-- Fixed navbar -->
    <nav class="navbar">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <p class="text-primary"><span class="showcase">A</span>M System</p>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
        <ul class="nav navbar-nav navbar-right nav-ul">
            <li><a href="teacher.php">Dashboard</a></li>
            <li><a href="cre-student.html">Create Student</a></li>
            <li><a href="student-ia.php">Marks Entry</a></li>
            <li><a href="notes.php">Upload</a></li>
            <li><a href="statistics.php">Statistics</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="logout.php">Logout</a></li>
          </ul>
        </div><!--Navbar-collapse -->
      </div>
    </nav>
 <div class="container">
  <div id="output"></div>
  <form id="getAttendance">
    <div class="form-group">
      <label class="text-white">Year of course</label>
      <select name="year" class="form-control">
        <?php foreach(range(date('Y',time()),1983) as $r) echo '<option>'.$r.'</option>'; ?>
      </select>
    </div>
    <div class="form-group">
      <label>Section</label>
      <select name="section" class="form-control">
      <option>1</option><option>2</option><option>3</option>	
    </select>
    </div>
    <div class="form-group">
      <label>Subject Code of Course</label>
      <input type="text" class="form-control" name="code" placeholder="Eg - COE-216">
      <span class="help-block">DDD-NNN where D : Department , N : Number</span>
    </div>
    <div class="form-group">
      <label>Roll Number</label>
      <input type="text" class="form-control" name="roll" placeholder="Eg - 262/CO/12">
      <span class="help-block">NNN/DD/YY where N : Number, D : Department , Y : Year</span>
    </div>
    <button class="btn btn-primary">View Performance</button>
  </form>
  </div>
  </div><!-- /.container --> 
  <script>
    $(document).ready(function () {
  if (gup("roll") && gup("code") && gup("year") && gup("section")) {
    $("#getAttendance select[name=year]").val(gup("year"));
    $("#getAttendance select[name=section]").val(gup("section"));
    $("#getAttendance input[name=code]").val(gup("code"));
    $("#getAttendance input[name=roll]").val(gup("roll").replace(/-/g, "/"));
    getAttendance();
  }
  $("#getAttendance").submit(function () {
    getAttendance();
    return false;
  });
});
function getAttendance() {
  var data = getFormElements("#getAttendance");
  var check = 0;
  jQuery.each(data, function (k, v) {
    if (v == "") {
      check++;
    }
  });
  if (check) {
    $("#output").html("<h2> Fill all details! </h2>");
    return;
  }
  $.ajax({
    url: "php/get_attendance.php",
    type: "post",
    data: data,
    dataType: "json",
    success: function (r) {
      console.log(r);
      if (r.error == "NO_RECORD") {
        $("#output").html("<h2> No records found for this class!</h2>");
        return;
      } else if (r.error == "NOT_IN_RECORDS") {
        $("#output").html(
          "<h2> This roll number doesn't belong to this class! </h2>"
        );
        return;
      } else if (r.error == "DB_ERROR") {
        $("#output").html("<h2> We are facing issues at backend! </h2>");
        return;
      } else {
        $("#output").html(
          "<h1 class='text-white'> Faculty : " +
            r.teacher +
            "</h1><h4 class='text-white'>Subject : " +
            $('input[name="code"]').val() +
            "</h4><h4 class='text-white'>Total Classes : " +
            r.count +
            "</h4><div id='chart'></div><div id='pie'></div>"
        );
        generateGraph(r.timeline);
        $("#pie").html(
          '<input class="knob" value="' +
            Math.floor(r.percent) +
            '" data-readonly="true" data-thickness=".4" readonly="readonly" data-width="150" data-height="150" data-angleOffset=180 data-fgColor="#87AB66" data-bgColor="#E1EAD9">'
        );
        loadKnob();
        return;
      }
    },
    error: function (r) {
      console.log(r);
    },
  });
}
function getFormElements(formID) {
  var data = {};
  $(formID + " input," + formID + " select," + formID + " textarea").each(
    function (k, v) {
      data[$(this).attr("name")] = $(this).val();
    }
  );
  return data;
}
function generateGraph(data) {
  $("#chart").highcharts({
    chart: { type: "column" },
    title: { text: "Attendance Tracker", x: -20 },
    subtitle: { text: "", x: -20 },
    xAxis: {
      gridLineWidth: 0,
      title: "Dates",
      categories: $.map(data, function (v, k) {
        return new Date(1000 * k).toDateString();
      }),
    },
    yAxis: {
      gridLineWidth: 0,
      title: { text: "Presence" },
    },
    legend: {
      layout: "vertical",
      align: "right",
      verticalAlign: "middle",
      borderWidth: 0,
    },
    series: [
      {
        name: "Presence",
        data: $.map(data, function (v, k) {
          return v;
        }),
        color: "#D10057",
      },
    ],
  });
}
function gup(name) {
  name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
  var regexS = "[\\?&]" + name + "=([^&#]*)";
  var regex = new RegExp(regexS);
  var results = regex.exec(window.location.href);
  if (results == null) return "";
  else return results[1];
}

  </script>
 </body>
</html>
