<!DOCTYPE html>
<html>
  <head>
    <title>Am System</title>
    <!--Bootstrap Linking-->
    <link
      rel="stylesheet"
      href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"
    />
    <link rel="stylesheet" href="css/s-list.css">
    <style>
      .myform{
            margin-top: 3%;
            background-color: #0275d8;
            width: 30%;
            display: block;
            margin-left: auto;
            margin-right: auto;
            padding: 6%;
            border-radius: 20px;
        }
        .label-input{
          font-style: italic;
        }
        .list{
            color: white;
            margin-left: 5%;
        }.show{
            margin-left: -10%;
            margin-top: 2%;
        }h5{
            color: white;
            font-style: italic;
        }
    </style>
</head>
<body>
    <button type="button" class="btn" id="menu-icon" onclick="dashboardBack()">
        <span>Dashboard</span>
    </button><br><br>
    <p class="text-center text-primary show"><span class="showcase">A</span>M System</p>
    <h1 class="text-center">Text Books & Notes</h1>
    <div class="myform">
        <form method="POST" action="upload.php" enctype="multipart/form-data">
            <h5>Find the download button!</h5><br>
            <?php
                $files = scandir("uploads");
              for ($a = 2; $a < count($files); $a++)
                    {
                        ?>
                        <p>
                            <?php echo $files[$a]; ?>
                            <a class="list" href="uploads/<?php '<p class="text">echo $files[$a];</p>' ?>" download="<?php echo $files[$a]; ?>">
                                Download
                            </a>
                        </p>
                        <?php
                    }
            ?>
        </form>
    </div>
    <script>
       function dashboardBack(){
           location.href = 'dashboard.html';
       }
   </script>
</body>
</html>

