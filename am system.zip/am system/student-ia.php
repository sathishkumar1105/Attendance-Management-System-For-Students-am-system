<!DOCTYPE html>
<html>
  <head>
    <title>Am System</title>
    <!--Bootstrap Linking-->
    <link
      rel="stylesheet"
      href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"
    />
    <!--CSS File Linking-->
    <link rel="stylesheet" href="css/student-ia.css" />
    <style>
    p {
        margin-left: 9%;
        margin-top: -5%;
      }
      .active {
        opacity: 0.5;
      }
      .active:hover {
        opacity: 1;
      }
      h2{
        color: white;
        margin-top: 5%;
        font-style: italic;
      }
    </style>
  </head>
  <body>
    <!-- Fixed navbar -->
    <nav class="navbar">
      <div class="container">
        <div class="navbar-header">
          <button
            type="button"
            class="navbar-toggle collapsed"
            data-toggle="collapse"
            data-target="#navbar"
            aria-expanded="false"
            aria-controls="navbar"
          >
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right nav-ul">
            <li><a href="teacher.php">Dashboard</a></li>
            <li>
              <a href="cre-student.html">Create Student</a>
            </li>
            <li class="active"><a href="student-ia.php">Marks Entry</a></li>
            <li><a href="notes.php">Upload</a></li>
            <li><a href="statistics.php">Statistics</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="logout.php">Logout</a></li>
          </ul>
        </div>
        <!--/.nav-collapse -->
      </div>
    </nav>
    <!--Create Student-->
    <div class="form-container">
      <p class="text-primary"><span class="showcase">A</span>M System</p>
      <h2 class="text-center text-white">Student Assessment Entry</h2>
      <form action="entry.php" method="POST" id="myform">
          <div class="basic-d">
        <div class="form-group">
          <input
            type="text"
            name="username"
            placeholder="Name"
            required
            class="form-control input-bc"
            id="name"
          />
        </div>
        <div class="form-group">
          <input
            type="text"
            name="password"
            class="form-control input-bc"
            placeholder="Batch No"
            required
            id="batch-no"
          />
        </div>
      </div>
        <div class="subjects">
        <div class="form-group">
          <input
            type="text"
            name="gender"
            required
            class="form-control input-fc"
            id="gender"
            placeholder="Enter the Mark of Subject 1"
          />
        </div>
        <div class="form-group">
          <input
            type="text"
            name="course"
            required
            class="form-control input-fc"
            id="course"
            required
            placeholder="Enter the Mark of Subject 2"
          />
        </div>
        <div class="form-group">
          <input
            type="text"
            name="branch"
            required
            class="form-control input-fc"
            id="branch"
            placeholder="Enter the Mark of Subject 3"
          />
        </div>
        <div class="form-group">
          <input
            type="text"
            name="email"
            required
            class="form-control input-fc"
            id="email"
            placeholder="Enter the Mark of Subject 4"
          />
        </div>
        <div class="form-group">
          <input
            type="text"
            name="phoneCode"
            required
            class="form-control input-fc"
            id="phoneCode"
            placeholder="Enter the Mark of Subject 5"
          />
        </div>

        <div class="form-group">
          <input
            type="text"
            name="phone"
            required
            class="form-control input-fc"
            id="PhoneNumber"
            placeholder="Enter the Mark of Subject 6"
          />
        </div>
        </div>
        <label class="label-input">You need calculator? Go to the dashboard</label> 
        <input
          type="submit"
          class="btn btn-primary"
          id="submit"
          value="Submit"
          name="submit"
        />
      </form>
    </div>
  </body>
</html>
