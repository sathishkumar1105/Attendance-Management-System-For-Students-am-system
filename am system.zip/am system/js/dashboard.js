//fade in Side Bar
function sideBar(){
    document.getElementById('sidebar').style.display = "block";
    document.getElementById('menu-icon').style.display = "none";
    document.getElementById('close-icon').style.display = "block"; 

}
//fade out Side Bar
function closeSideBar(){
    document.getElementById('sidebar').style.display = "none";
    document.getElementById('menu-icon').style.display = "block";
    document.getElementById('close-icon').style.display = "none";     
}

//click menu btn adjust the position based on the sidebar width and height
$("#menu-icon").click(function(){
    $('.page-content').animate({marginLeft: '15%', marginTop: '5%'});
})

//click close btn came to the default position
$("#close-icon").click(function(){
    $('.page-content').animate({marginLeft: '0%', marginTop: '0%'});
})

//counter system 
let countEl = document.getElementById("count-el")
let saveEl = document.getElementById("save-el")
let count = 0

 function increment() {
     count += 1
     countEl.innerText = count
 }

 function save(){
     saveEl.textContent += count + " - "
 }

//counter fade in 
$(".counter-sys").click(function(){       
    $(".page-content").hide();
    $("#sidebar").hide();
    $("#log-icon").hide();
    $('.counter').fadeIn('slow');  
})

//counter fade out
$(".c-close").click(function(){       
    $('.counter').hide();
    $("#log-icon").show();
    $('.page-content').fadeIn(150);
    $('.page-content').animate({marginLeft: "-1%"});
    $('#menu-icon').show();
})

//Timer Fade In
$(".timer-sys").click(function(){       
    $(".page-content").hide();
    $("#sidebar").hide();
    $("#log-icon").hide();
    $('.timer').fadeIn('slow');  
})
    
//Timer fade out
    $(".t-close").click(function(){       
    $('.timer').hide();
    $("#log-icon").show();
    $('.page-content').fadeIn(150);
    $('.page-content').animate({marginLeft: "-1%"});
    $('#menu-icon').show();
})

//Timer system
let a;
let date;
let time;
const options = {
	weekday: "long",
	year:"numeric",
	month: "long",
	day: "numeric"
};

setInterval(() => {
    a = new Date();
	date = a.toLocaleDateString(undefined, options);
	time = a.getHours() + " : " + a.getMinutes() + " : " + a.getSeconds();
	document.getElementById("time").innerHTML = time + "<br>on " + date;
    }, 1000);

//To Do List
document.querySelector('#push').onclick = function(){
    if(document.querySelector('#newtask input').value.length == 0){
        alert("Please Enter a Task")
    }
    else{
        document.querySelector('#tasks').innerHTML += `
            <div class="task">
                <span id="taskname">
                    ${document.querySelector('#newtask input').value}
                </span>
                <button class="delete">
                    <i class="far fa-trash-alt"></i>
                </button>
            </div>
        `;

    var current_tasks = document.querySelectorAll(".delete");
        for(var i=0; i<current_tasks.length; i++){
            current_tasks[i].onclick = function(){
                this.parentNode.remove();
            }
        }
    }
}

//To Do List Fade In
$(".toDoList").click(function(){       
    $(".page-content").hide();
    $("#sidebar").hide();
    $("#log-icon").hide();
    $('.to-do-list').fadeIn('slow');  
})
    
//To Do List fade out
    $(".to-close").click(function(){       
    $('.to-do-list').hide();
    $("#log-icon").show();
    $('.page-content').fadeIn(150);
    $('.page-content').animate({marginLeft: "-1%"});
    $('#menu-icon').show();
})

//Calcualtor
let display = document.getElementById('display');

let buttons = Array.from(document.getElementsByClassName('button'));

buttons.map( button => {
    button.addEventListener('click', (e) => {
        switch(e.target.innerText){
            case 'C':
                display.innerText = '';
                break;
            case '=':
                try{
                    display.innerText = eval(display.innerText);
                } catch {
                    display.innerText = "Error"
                }
                break;
            case '←':
                if (display.innerText){
                   display.innerText = display.innerText.slice(0, -1);
                }
                break;
            default:
                display.innerText += e.target.innerText;
        }
    });
});

//Calculator Fade In
$(".calculator").click(function(){       
    $(".page-content").hide();
    $("#sidebar").hide();
    $("#log-icon").hide();
    $('.cal').fadeIn('slow');  
})
    
//Calculator fade out
    $(".cal-close").click(function(){       
    $('.cal').hide();
    $("#log-icon").show();
    $('.page-content').fadeIn(150);
    $('.page-content').animate({marginLeft: "-1%"});
    $('#menu-icon').show();
})

function facultyLogin(){
    var input = windows.prompt("Enter Your College ID");
    if(input=== "sce2022" || input === "sce2022"){
        location.href = "index.php";
    }else{
        alert("Please Check Your College ID!");
    }
}