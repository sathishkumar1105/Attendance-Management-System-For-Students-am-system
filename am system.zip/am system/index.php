<?php
  session_start();
  $isIndex = 1;
  if(array_key_exists('teacher_id',$_SESSION) && isset($_SESSION['teacher_id'])) {
   header('Location: teacher.php');
  } else {
    if(!$isIndex) header('Location: index.php');
  }
?>
<!DOCTYPE html>
<html>
 <head>
  <link rel="stylesheet" href="css/style.css"/>
  <title>Am System</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/bootstrap-theme.min.css">
  <link rel="stylesheet" href="css/index.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/login.js"></script>
  <link href="navbar-fixed-top.css" rel="stylesheet">
  <style>
    .f-right{
      position: absolute;
      top: 0;
      right: 0;
      margin: 2%
    }
  </style>
 </head>
 <body>
 
  <div class="container">
    <br>
  <p class="text-center text-primary"><span class="showcase">A</span>M System</p>
  <button class="btn btn-primary f-right" onclick="dashboardBack()">Dashboard</button>
    <h2 class="text-center title">Faculty Login</h2><br><br><br>
    <div class="alert alert-warning hidden">
      <span></span>
      <button type="button" class="close" onclick="$('.alert').addClass('hidden');">&times;</button>
    </div>
    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th class="text-center">Login</th>
          <!--<th>Sign Up</th>-->
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <form id="login">
              <div class="form-group">
                <label>Email ID</label>
                <input class="form-control" placeholder="Email" type="email" name="email">
              </div>
              <div class="form-group">
                <label>Password</label>
                <input class="form-control" placeholder="Password" type="password" name="password">
              </div>
              <p class="text-muted">You need sign up ? kindly request the admin!</p>
              <a href="request.html">click to continue</a>
              <button class="btn btn-primary pull-right">Login</button>
            </form>
          </td>
          <!--
          <td class="d-none">
            <form id="signup">
              <div class="form-group">
                <label>Name</label>
                <input class="form-control" placeholder="Name" type="text" name="name">
              </div>
              <div class="form-group">
                <label>Phone Number</label>
                <input class="form-control" placeholder="Phone" type="text" name="phone">
              </div>
              <div class="form-group">
                <label>Email ID</label>
                <input class="form-control" placeholder="Email" type="email" name="email">
              </div>
              <div class="form-group">
                <label>Password</label>
                <input class="form-control" placeholder="Password" type="password" name="password">
                <span class="help-block">Password should be 6 characters long.</span>
              </div>
              <div class="form-group">
                <label>Re-type Password</label>
                <input class="form-control" placeholder="Re-type Password" type="password" name="password2">
              </div>
              <button class="btn btn-primary pull-right">Sign Up</button>
            </form>
          </td>-->
        </tr>
      </tbody>
    </table>
  </div>
    </div><!-- /.container -->
  <script>
       function dashboardBack(){
           location.href = 'dashboard.html';
       }
  </script>
 </body>
</html>
