<?php
if (isset($_POST['submit'])) {
    if (isset($_POST['semno']) && isset($_POST['subcode']) &&
        isset($_POST['subname']) && isset($_POST['date']) &&
        isset($_POST['periodno'])) {
        
        $semNo = $_POST['semno'];
        $subCode = $_POST['subcode'];
        $subName = $_POST['subname'];
        $date = $_POST['date'];
        $periodNo = $_POST['periodno'];
        $host = "localhost";
        $dbUsername = "root";
        $dbPassword = "";
        $dbName = "tests";
        $conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);
        if ($conn->connect_error) {
            die('Could not connect to the database.');
        }
        else {
            $Select = "SELECT periodno FROM register WHERE periodno = ? LIMIT 1";
            $Insert = "INSERT INTO register(semno, subcode, subname, date, periodno) values(?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($Select);
            $stmt->bind_param("s", $periodNo);
            $stmt->execute();
            $stmt->bind_result($resultEmail);
            $stmt->store_result();
            $stmt->fetch();
            $rnum = $stmt->num_rows;
            if ($rnum == 0) {
                $stmt->close();
                $stmt = $conn->prepare($Insert);
                $stmt->bind_param("sssii", $semNo, $subCode, $subName, $date, $periodNo);
                if ($stmt->execute()) {
                    echo "<script>
                    alert('New record inserted sucessfully.');
                    location.href = 'dashboard.html';
                    </script>";
                }
                else {
                    echo $stmt->error;
                }
            }
            else {
                echo "<script>
                alert('Already this period exceed');
                location.href = 'dashboard.html';
                </script>";
            }
            $stmt->close();
            $conn->close();
        }
    }
    else {
        echo "<script>alert('All field are required.')</script>";
        die();
    }
}
else {
    echo "<script>alert('Submit button is not set')</script>";
}
?>