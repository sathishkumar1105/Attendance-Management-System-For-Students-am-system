<?php
if (isset($_POST['submit'])) {
    if (isset($_POST['username']) && isset($_POST['password']) &&
        isset($_POST['gender']) && isset($_POST['email']) &&
        isset($_POST['branch']) && isset($_POST['course']) &&
        isset($_POST['phoneCode']) && isset($_POST['phone'])) {
        
        $username = $_POST['username'];
        $password = $_POST['password'];
        $gender = $_POST['gender'];
        $email = $_POST['email'];
        $branch = $_POST['branch'];
        $course = $_POST['course'];
        $phoneCode = $_POST['phoneCode'];
        $phone = $_POST['phone'];
        $host = "localhost";
        $dbUsername = "root";
        $dbPassword = "";
        $dbName = "entry";
        $conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);
        if ($conn->connect_error) {
            die('Could not connect to the database.');
        }
        else {
            $Select = "SELECT password FROM marks WHERE password = ? LIMIT 1";
            $Insert = "INSERT INTO marks(username, password, gender, email, branch, course, phoneCode, phone) values(?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($Select);
            $stmt->bind_param("s", $password);
            $stmt->execute();
            $stmt->bind_result($resultEmail);
            $stmt->store_result();
            $stmt->fetch();
            $rnum = $stmt->num_rows;
            if ($rnum == 0) {
                $stmt->close();
                $stmt = $conn->prepare($Insert);
                $stmt->bind_param("ssssiiii",$username, $password, $gender, $email, $branch, $course, $phoneCode, $phone);
                if ($stmt->execute()) {
                    echo "<script>
                    alert('New record inserted sucessfully.');
                    location.href = 'mark-list.php';
                    </script>";
                }
                else {
                    echo $stmt->error;
                }
            }
            else {
                echo "<script>
                alert('Someone already registers using this email.');
                location.href = 'student-ia.php';
                </script>";
            }
            $stmt->close();
            $conn->close();
        }
    }
    else {
        echo "<script>alert('All field are required.')</script>";
        die();
    }
}
else {
    echo "<script>alert('Submit button is not set')</script>";
}
?>