<!DOCTYPE html>
<html>
    <head>
        <title>Am System</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/s-list.css">
        <style>
            .a-list {
                margin-top: 3%;
                margin-left: 5%;
            }
        </style>
    </head>
<body>
    <button type="button" class="btn" id="menu-icon" onclick="dashboardBack()">
        <span>Dashboard</span>
    </button><br><br>
    <p class="text-center text-primary"><span class="showcase">A</span>M System</p>
    <h1 class="text-center">Student List</h1>
    <table class="a-list">
     <thead class="bg-dark">
        <tr>
            <th scope="col" >Name</th>
            <th scope="col">Batch No</th>
            <th scope="col">Gender</th>
            <th scope="col">Email</th>
            <th scope="col">Branch</th>
            <th scope="col">Course</th>
            <th scope="col">Phone Code</th>
            <th scope="col">Phone</th>
        </tr>
     </thead>
      
     <?php $conn = mysqli_connect("localhost", "root", "", "tests");
        // Check connection
        if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        }
        $sql = "SELECT username, password, gender, email, branch, course, phoneCode, phone FROM register";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
        echo "<tr class='body-row'><td>"  . $row["username"] . "</td><td>"
        . $row["password"]. "</td><td>" . $row["gender"] . "</td><td>" . $row["email"] 
        . "</td><td>" . $row["branch"] . "</td><td>" . $row["course"]
        . "</td><td>". $row["phoneCode"]. "</td><td>". $row["phone"] . "</td></tr>" ;
        }
        echo "</table>";
        } else { echo "0 results"; }
        $conn->close();
     ?>
   </table>

   <script>
       function dashboardBack(){
           location.href = 'dashboard.html';
       }
   </script>
</body>
</html>